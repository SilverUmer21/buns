import bpy
from pathlib import Path
root = Path(__file__).resolve().parents[1]
s = bpy.data.scenes['Pip_Studio']
bpy.context.window.scene = s
s.cycles.samples = 24
s.render.resolution_x = s.render.resolution_y = 640
s.render.filepath = str(root / 'renders' / 'pip-proof.png')
s.render.film_transparent = False
bpy.ops.render.render(write_still=True)
