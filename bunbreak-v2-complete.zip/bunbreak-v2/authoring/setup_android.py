"""Fetch official tools, with timeouts and ZIP member extraction to avoid huge downloads.

Run only in a network-enabled command. Every request uses the configured proxy/CA.
No account credentials or private signing key are needed for this debug build.
"""
import binascii
import io
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import time
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT.parent / 'scratch' / 'bunbreak-sdk'
SDK = TOOLS / 'android-sdk'
TOOLS.mkdir(parents=True, exist_ok=True)
SOURCES = []


def fetch(url, start=None, length=None):
    headers = {'User-Agent': 'Bunbreak-local-build/0.2', 'Accept': '*/*'}
    if start is not None:
        headers['Range'] = f'bytes={start}-{start + length - 1}'
    print('DOWNLOAD', url.split('?')[0], f'bytes {start}+{length}' if start is not None else '', flush=True)
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=25) as response:
        if start is not None and response.status != 206:
            raise RuntimeError(f'Server did not honor bounded range request: {response.status}')
        chunks, count, last = [], 0, time.monotonic()
        begun = last
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            chunks.append(chunk)
            count += len(chunk)
            now = time.monotonic()
            if now - last > 4:
                print('PROGRESS', count // 1048576, 'MiB', round(now - begun, 1), 'sec', flush=True)
                last = now
            if now - begun > 150:
                raise TimeoutError('Download unit exceeded 150 seconds; local work is preserved')
        return b''.join(chunks)


def sdk_package(xml, name, destination, strip_root):
    marker = destination / '.bunbreak-installed'
    if marker.exists():
        print('CACHED SDK', name, flush=True)
        return
    package = next(p for p in xml.iter() if p.tag.endswith('remotePackage') and p.get('path') == name)
    archives = [node for node in package.iter() if node.tag.endswith('archive')]
    archive = next(a for a in archives if any(n.tag.endswith('host-os') and n.text == 'linux' for n in a) or not any(n.tag.endswith('host-os') for n in a))
    relative = next(n.text for n in archive.iter() if n.tag.endswith('url'))
    checksum_node = next(n for n in archive.iter() if n.tag.endswith('checksum'))
    url = 'https://dl.google.com/android/repository/' + relative
    cache = TOOLS / Path(relative).name
    if not cache.exists():
        data = fetch(url)
        cache.write_bytes(data)
    else:
        data = cache.read_bytes()
    import hashlib
    algorithm = checksum_node.get('type', 'sha1')
    assert hashlib.new(algorithm, data).hexdigest() == checksum_node.text.strip(), ('Official SDK checksum', name)
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for member in z.infolist():
            parts = Path(member.filename).parts
            if strip_root:
                parts = parts[1:]
            if not parts or '..' in parts:
                continue
            target = destination.joinpath(*parts)
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(member))
                mode = member.external_attr >> 16
                if mode & 0o111:
                    target.chmod(0o755)
    marker.write_text(url)
    SOURCES.append({'sdk': name, 'url': url, algorithm: checksum_node.text.strip()})
    print('INSTALLED SDK', name, flush=True)


class RemoteZip(io.RawIOBase):
    def __init__(self, url, size):
        self.url, self.size, self.cursor = url, size, 0
        self.cache_start, self.cache = max(0, size - 131072), b''
        self.cache = fetch(url, self.cache_start, size - self.cache_start)

    def seekable(self):
        return True

    def seek(self, offset, whence=0):
        self.cursor = offset if whence == 0 else (self.cursor if whence == 1 else self.size) + offset
        return self.cursor

    def tell(self):
        return self.cursor

    def read(self, size=-1):
        size = min(self.size - self.cursor, size if size >= 0 else self.size - self.cursor)
        if self.cursor >= self.cache_start and self.cursor + size <= self.cache_start + len(self.cache):
            data = self.cache[self.cursor - self.cache_start:self.cursor - self.cache_start + size]
        else:
            data = fetch(self.url, self.cursor, size)
        self.cursor += len(data)
        return data


def templates():
    target = Path(os.environ['XDG_DATA_HOME']) / 'godot' / 'export_templates' / '4.6.3.stable'
    target.mkdir(parents=True, exist_ok=True)
    wanted = ['android_debug.apk', 'linux_debug.x86_64']
    if all((target / name).exists() for name in wanted):
        print('CACHED Godot templates', flush=True)
        return
    release = json.loads(fetch('https://api.github.com/repos/godotengine/godot-builds/releases/tags/4.6.3-stable'))
    asset = next(a for a in release['assets'] if a['name'].endswith('_export_templates.tpz'))
    # The public release URL and server signed redirect are handled by urllib.
    url = asset['browser_download_url'] + '?bunbreak=' + str(int(time.time()))
    remote = RemoteZip(url, asset['size'])
    with zipfile.ZipFile(remote) as archive:
        for name in wanted:
            if (target / name).exists():
                continue
            info = next(i for i in archive.infolist() if i.filename.endswith('/' + name))
            header = fetch(url, info.header_offset, 30)
            fields = struct.unpack('<4s5H3I2H', header)
            assert fields[0] == b'PK\x03\x04'
            data_start = info.header_offset + 30 + fields[-2] + fields[-1]
            compressed = fetch(url, data_start, info.compress_size)
            data = zlib.decompress(compressed, -15) if info.compress_type == zipfile.ZIP_DEFLATED else compressed
            assert len(data) == info.file_size and binascii.crc32(data) & 0xffffffff == info.CRC, ('Official template CRC', name)
            (target / name).write_bytes(data)
            if name.endswith('x86_64'):
                (target / name).chmod(0o755)
            SOURCES.append({'godot_template': name, 'url': asset['browser_download_url'], 'crc32': f'{info.CRC:08x}'})
            print('INSTALLED TEMPLATE', name, len(data), flush=True)
    (target / 'version.txt').write_text('4.6.3.stable')


def main():
    repository = TOOLS / 'repository.xml'
    if not repository.exists():
        repository.write_bytes(fetch('https://dl.google.com/android/repository/repository2-1.xml'))
    xml = ET.fromstring(repository.read_bytes())
    sdk_package(xml, 'platform-tools', SDK, False)
    sdk_package(xml, 'build-tools;35.0.1', SDK / 'build-tools' / '35.0.1', True)
    sdk_package(xml, 'platforms;android-35', SDK / 'platforms' / 'android-35', True)
    templates()
    keystore = TOOLS / 'debug.keystore'
    if not keystore.exists():
        subprocess.run(['keytool', '-genkeypair', '-keystore', str(keystore), '-storepass', 'android', '-alias', 'androiddebugkey', '-keypass', 'android', '-dname', 'CN=Android Debug,O=Android,C=US', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000'], check=True, timeout=30)
    config = Path(os.environ['XDG_CONFIG_HOME']) / 'godot'
    config.mkdir(parents=True, exist_ok=True)
    settings = config / 'editor_settings-4.6.tres'
    settings.write_text('[gd_resource type="EditorSettings" format=3]\n\n[resource]\n' +
        f'export/android/android_sdk_path = "{SDK}"\n' +
        'export/android/java_sdk_path = "/usr/lib/jvm/java-21-openjdk-amd64"\n' +
        f'export/android/debug_keystore = "{keystore}"\n' +
        'export/android/debug_keystore_user = "androiddebugkey"\n' +
        'export/android/debug_keystore_pass = "android"\n')
    (ROOT / 'reports' / 'toolchain-sources.json').write_text(json.dumps(SOURCES, indent=2))
    print('ANDROID TOOLCHAIN READY', flush=True)


if __name__ == '__main__':
    main()
