"""An honest art proof of the playable slice, not a Godot runtime screenshot."""
import bpy
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'authoring'))
import build_assets as author

scene = bpy.data.scenes['Board_Showcase']
bpy.context.window.scene = scene
for ob in list(scene.objects):
    if ob.instance_type == 'COLLECTION':
        bpy.data.objects.remove(ob, do_unlink=True)

def put(key, location=(0, 0, 0), scale=1, tilt=0):
    author.instance(scene, {'title': key, 'collection': bpy.data.collections[key]}, location, scale, tilt=tilt)

put('TurquoiseTray')
put('WaferGate', (0, 3.45, .215))
put('ExitPlate', (0, 4.43, .215), .70)
put('JellyBumper', (0, 1.38, .215))
for x, y in [(-1.48, -3.15), (1.48, -3.15), (-1.48, -.70), (1.48, -.70)]:
    put('Pip', (x, y, .215), .70, -.30)
scene.cycles.samples = 24
scene.render.resolution_x, scene.render.resolution_y = 600, 840
scene.render.filepath = str(ROOT / 'renders' / 'level-art-proof.png')
bpy.ops.render.render(write_still=True)
