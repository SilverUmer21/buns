#!/usr/bin/env bash
set -u
TASK_ROOT=/workspace/bunbreak-v2
. "$TASK_ROOT/authoring/environment.sh"
export LIBGL_ALWAYS_SOFTWARE=1
export DISPLAY=:97
timeout 45 godot --headless --editor --path "$TASK_ROOT/godot" --import > "$TASK_ROOT/reports/final-import.log" 2>&1
mkdir -p /tmp/.X11-unix
chmod 1777 /tmp/.X11-unix
XORG_PID=""
cleanup() { if [ -n "$XORG_PID" ]; then kill "$XORG_PID" 2>/dev/null || true; fi; }
trap cleanup EXIT
/usr/lib/xorg/Xorg :97 -seat bunbreak -noreset -nolisten tcp -config "$TASK_ROOT/authoring/xorg-dummy.conf" -logfile "$TASK_ROOT/reports/xorg.log" -sharevts -novtswitch > "$TASK_ROOT/reports/xorg-stdout.log" 2>&1 &
XORG_PID=$!
python3 -c 'import time; time.sleep(2)'
if timeout 5 xdpyinfo -display :97 > "$TASK_ROOT/reports/display-info.log" 2>&1; then
    echo "GRAPHICS READY: capturing actual Godot runtime"
    timeout 60 godot --path "$TASK_ROOT/godot" --rendering-method gl_compatibility --audio-driver Dummy --resolution 720x1120 res://review.tscn -- --mode=portrait > "$TASK_ROOT/reports/capture-portrait.log" 2>&1
    timeout 60 godot --path "$TASK_ROOT/godot" --rendering-method gl_compatibility --audio-driver Dummy --resolution 1280x800 res://review.tscn -- --mode=desktop > "$TASK_ROOT/reports/capture-desktop.log" 2>&1
    timeout 240 godot --path "$TASK_ROOT/godot" --rendering-method gl_compatibility --audio-driver Dummy --resolution 720x1120 --fixed-fps 30 --write-movie "$TASK_ROOT/builds/gameplay.avi" res://review.tscn > "$TASK_ROOT/reports/capture-video.log" 2>&1
    if [ -f "$TASK_ROOT/builds/gameplay.avi" ]; then
        timeout 90 ffmpeg -nostdin -y -i "$TASK_ROOT/builds/gameplay.avi" -c:v libx264 -crf 21 -pix_fmt yuv420p -movflags +faststart -c:a aac "$TASK_ROOT/builds/Bunbreak-v2-gameplay.mp4" > "$TASK_ROOT/reports/video-encode.log" 2>&1
    fi
else
    echo "GRAPHICS UNAVAILABLE: see reports/xorg.log; continuing independent Android setup"
fi
echo "ANDROID: fetching official SDK tools and matching Godot templates"
if timeout 420 python3 -u "$TASK_ROOT/authoring/setup_android.py" > "$TASK_ROOT/reports/android-setup.log" 2>&1; then
    timeout 300 godot --headless --path "$TASK_ROOT/godot" --export-debug Android "$TASK_ROOT/builds/Bunbreak-v2-android.apk" > "$TASK_ROOT/reports/android-export.log" 2>&1
    timeout 120 godot --headless --path "$TASK_ROOT/godot" --export-debug Linux "$TASK_ROOT/builds/Bunbreak-v2-linux.x86_64" > "$TASK_ROOT/reports/linux-export.log" 2>&1
    /workspace/scratch/bunbreak-sdk/android-sdk/build-tools/35.0.1/apksigner verify --verbose --print-certs "$TASK_ROOT/builds/Bunbreak-v2-android.apk" > "$TASK_ROOT/reports/android-signature.log" 2>&1
    /workspace/scratch/bunbreak-sdk/android-sdk/build-tools/35.0.1/aapt dump badging "$TASK_ROOT/builds/Bunbreak-v2-android.apk" > "$TASK_ROOT/reports/android-package.log" 2>&1
else
    echo "ANDROID SETUP STOPPED: bounded attempt failed; local project and assets are preserved"
fi
echo "BUILD FINISH PASS COMPLETE"
