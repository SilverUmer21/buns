"""Package actual assets, honest review proofs and a cache-free playable project."""
import hashlib
import json
from pathlib import Path
import zipfile
import fitz
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
INK = (.13, .36, .32)
MUTED = (.36, .47, .42)
doc = fitz.open()

def page(title, subtitle):
    p = doc.new_page(width=864, height=612)
    p.draw_rect(p.rect, fill=(1, .985, .95), color=None)
    p.insert_text((32, 26), 'BUNBREAK / SUNSHINE KITCHEN / V2', fontsize=10, color=INK, fontname='hebo')
    p.insert_text((32, 63), title, fontsize=26, color=INK, fontname='hebo')
    p.insert_textbox(fitz.Rect(32, 78, 832, 116), subtitle, fontsize=11, color=MUTED)
    p.insert_text((32, 593), 'ACTUAL BLENDER ASSETS + PLAYABLE GODOT SLICE', fontsize=9, color=MUTED)
    p.insert_text((806, 593), str(len(doc)), fontsize=9, color=MUTED)
    return p

def image(p, path, rect):
    p.insert_image(fitz.Rect(rect), filename=str(ROOT / path), keep_proportion=True)

def main():
    previews = {}
    for path in sorted((ROOT / 'renders' / 'transparent').glob('*.png')):
        with Image.open(path) as im:
            assert im.mode == 'RGBA' and im.getchannel('A').getextrema() == (0, 255)
            bounds = im.getchannel('A').getbbox()
            assert bounds[0] > 1 and bounds[1] > 1 and bounds[2] < im.width - 1 and bounds[3] < im.height - 1, (path.name, bounds)
            previews[path.stem] = {'size': list(im.size), 'alpha_bounds': list(bounds)}
    assert len(previews) == 8
    (ROOT / 'reports' / 'render-validation.json').write_text(json.dumps({'passed': True, 'transparent_previews': previews}, indent=2))
    game = json.loads((ROOT / 'reports' / 'game-validation.json').read_text())
    assert game['passed'] and len(game['checks']) == 48
    p = page('Rounder. Brighter. Ready to wobble.', 'Actual rebuilt 3D meshes: Pip, Berry and Mango. Soft dough, short crests, broad readable faces.')
    image(p, 'renders/bunbreak-family.png', (32, 112, 832, 576))
    p = page('The concept target.', 'AI generated design reference made before rebuilding the models. This page is concept art, not a render of the delivered geometry.')
    image(p, 'references/mochi-concept-v2.png', (32, 113, 832, 574))
    p = page('Squash, blink, hop.', 'Actual evaluated Blender rig poses. Eight 60 fps clips per character; held pull and reactive spring motion are also implemented in Godot.')
    image(p, 'renders/animation-states.png', (192, 109, 672, 575))
    p = page('The big escape: one playable level.', 'Blender art proof matching the level start. Four Pips, a jelly bumper, one Mango gate and an escape plate. Not a Godot runtime screenshot.')
    image(p, 'renders/level-art-proof.png', (32, 111, 363, 575))
    image(p, 'renders/props.png', (385, 113, 832, 432))
    p.insert_textbox(fitz.Rect(392, 452, 820, 569), 'Pull backwards and release. Pip + Pip = Berry. Berry + Berry = Mango. The Mango opens the gate at any speed.\n\nUndo, Retry, pause, mute and a verified Show me replay are included. Unlimited attempts.', fontsize=12, color=INK)
    for key, label in [('pip', 'Pip / cream mochi'), ('berry', 'Berry / bright strawberry'), ('mango', 'Mango / golden sunshine')]:
        p = page(label, 'Actual model turnarounds. Editable .blend sources and GLB exports are included.')
        image(p, 'renders/turnarounds/' + key + '.png', (32, 145, 832, 525))
        for x, text in [(139, 'FRONT'), (414, 'SIDE'), (679, 'BACK')]:
            p.insert_text((x, 550), text, fontsize=11, color=INK, fontname='hebo')
    p = page('Open it in Godot. Play it.', 'Godot 4.6.3 Standard / Compatibility renderer / touch and mouse / one polished slice')
    text = ('1. Unzip the Godot project and import project.godot.\n2. Let the GLB assets import. Press F5 to play main.tscn.\n3. Drag backwards from a bun, hold and release.\n4. Use Show me for a four-shot solution produced by the same physics.\n5. Open atelier.tscn and press F6 to inspect all assets and named clips.\n\n'
        'VERIFIED IN HEADLESS GODOT\n48 passing checks: real GLB imports and clip playback, held touch aiming and cancellation, immediate release, physics aim preview, Undo/Retry, pause/mute, tier gates, fast jelly contact, simultaneous merges and complete escape. Replays at 30/60/120 render FPS produce identical solver states.\n\n'
        'DELIVERED\n3 rigged characters, 5 props, 24 named clips, 11-bone rigs, editable morphs, Blender sources, GLB exports, Godot project, turnarounds and transparent previews.\n\n'
        'STILL PENDING\nA rendered Godot capture, Android APK and physical phone performance review. The environment-access step for a graphics window and official SDK/template downloads was cancelled before execution. The art proofs do not replace those checks.')
    p.insert_textbox(fitz.Rect(38, 126, 826, 570), text, fontsize=13, color=INK, lineheight=1.35)
    pdf = ROOT / 'Bunbreak-v2-review.pdf'
    doc.save(str(pdf), garbage=4, deflate=True)
    doc.close()
    files = []
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or '.godot' in path.parts or '__pycache__' in path.parts:
            continue
        if path.suffix in {'.log', '.blend1', '.blend2', '.pyc', '.avi'} or path.name in {'sha256.json', 'family-proof.png', 'pip-proof.png', 'pip_proof.blend', 'animation_review.blend'}:
            continue
        files.append(path)
    checksums = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    checksum_path = ROOT / 'reports' / 'sha256.json'
    checksum_path.write_text(json.dumps(checksums, indent=2))
    files.append(checksum_path)
    full_zip = ROOT.parent / 'bunbreak-v2-complete.zip'
    with zipfile.ZipFile(full_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in files:
            z.write(path, 'bunbreak-v2/' + str(path.relative_to(ROOT)))
    playable_zip = ROOT.parent / 'bunbreak-v2-godot.zip'
    with zipfile.ZipFile(playable_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in files:
            if 'godot' in path.relative_to(ROOT).parts:
                z.write(path, 'bunbreak-v2-godot/' + str(path.relative_to(ROOT / 'godot')))
        z.write(ROOT / 'README.md', 'bunbreak-v2-godot/README.md')
    for archive in [full_zip, playable_zip]:
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
        print('PACKAGED', archive, archive.stat().st_size, flush=True)
    print('REVIEW', pdf, pdf.stat().st_size, flush=True)

if __name__ == '__main__':
    main()
