"""Render the editable asset scenes. Open the master blend before running.

-- --quick : small family proof
-- --scene Family_Studio : render one final scene
-- --all : complete studio, transparent and turnaround set
"""
import bpy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
args = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []


def render(name, path, size=None, samples=48, transparent=False):
    scene = bpy.data.scenes[name]
    bpy.context.window.scene = scene
    scene.frame_set(1)
    scene.cycles.samples = samples
    scene.cycles.use_denoising = False
    scene.view_settings.exposure = -.3
    scene.render.film_transparent = transparent
    # A small edge-aware compositor filter cleans CPU sampling grain without
    # changing the modeled forms. No generated pixels replace the 3D render.
    if hasattr(bpy.types, 'CompositorNodeBilateralblur'):
        scene.use_nodes = True
        nodes = scene.node_tree.nodes
        nodes.clear()
        source = nodes.new('CompositorNodeRLayers')
        source.scene = scene
        blur = nodes.new('CompositorNodeBilateralblur')
        blur.iterations = 2
        blur.sigma_color = .12
        blur.sigma_space = 2
        out = nodes.new('CompositorNodeComposite')
        scene.node_tree.links.new(source.outputs['Image'], blur.inputs['Image'])
        scene.node_tree.links.new(source.outputs['Image'], blur.inputs['Determinator'])
        scene.node_tree.links.new(blur.outputs['Image'], out.inputs['Image'])
    if size:
        scene.render.resolution_x, scene.render.resolution_y = size
    scene.render.filepath = str(ROOT / 'renders' / path)
    print('RENDER_START', name, scene.render.filepath, flush=True)
    bpy.ops.render.render(write_still=True)
    print('RENDER_DONE', name, flush=True)


if '--quick' in args:
    render('Family_Studio', 'family-proof.png', (1000, 625), 16)
elif '--scene' in args:
    name = args[args.index('--scene') + 1]
    render(name, name.lower() + '.png')
elif '--board' in args:
    render('Board_Showcase', 'board-portrait.png', (900, 1260), samples=40)
    bpy.data.scenes['Board_Showcase'].camera.data.ortho_scale = 15.8
    render('Board_Showcase', 'board-desktop.png', (1280, 880), 32)
else:
    render('Family_Studio', 'bunbreak-family.png', (1280, 800), samples=64)
    render('Board_Showcase', 'board-portrait.png', (600, 840), samples=32)
    board = bpy.data.scenes['Board_Showcase']
    board.camera.data.ortho_scale = 15.8
    render('Board_Showcase', 'board-desktop.png', (960, 660), 24)
    render('Props_Studio', 'props.png', (1000, 714), samples=32)
    for key, title in [('pip', 'Pip'), ('berry', 'Berry'), ('mango', 'Mango')]:
        render('Turnaround_' + title, 'turnarounds/' + key + '.png', (1152, 448), samples=24)
        render(title + '_Studio', 'transparent/' + key + '.png', (640, 640), samples=32, transparent=True)
    for key, title in [('tray', 'TurquoiseTray'), ('wafer_gate', 'WaferGate'),
                       ('jelly_bumper', 'JellyBumper'), ('reward_star', 'RewardStar'),
                       ('exit_plate', 'ExitPlate')]:
        render(title + '_Studio', 'transparent/' + key + '.png', (640, 640), samples=24, transparent=True)
print('RENDER_BATCH_COMPLETE', flush=True)
