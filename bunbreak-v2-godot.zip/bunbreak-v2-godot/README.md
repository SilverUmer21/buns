# Bunbreak v2 · Sunshine Kitchen

Rounder buns, bright fruit colors and springy motion, with one playable 3D puzzle.

## Play in Godot

1. Install **Godot 4.6.3 Standard** (the .NET edition is unnecessary).
2. Import `godot/project.godot`, let its assets import, then press **F6** on `main.tscn` or **F5** to run the project.
3. Select a bun, drag backwards, hold, then release. Aim dots use the actual physics solver.
4. Merge two cream Pips into a pink Berry; merge two Berries into a golden Mango. A Mango opens the wafer gate at any speed. Reach the escape plate to finish.

In the smaller `bunbreak-v2-godot.zip`, `project.godot` is directly inside its top folder; the complete ZIP places it under `godot/`.

Undo restores the complete state before the last shot. Retry starts over. Show me replays a verified four-shot solution with the same physics. Pause freezes simulation and motion. Sound can be muted. Escape toggles pause. Touch cancellation and focus loss never fire a shot.

The game has unlimited attempts. Progress is saved locally in Godot's `user://progress.cfg`. There is no backend, advertising, purchase flow or network requirement in the game.

## Previews

- `Bunbreak-v2-review.pdf`: concept, actual model turnarounds, animation poses, level art and validation.
- `renders/bunbreak-family.png`: actual Blender render of the rebuilt family.
- `renders/animation-states.png`: real evaluated idle, blink, squash and hop poses.
- `renders/level-art-proof.png`: Blender art proof matching the playable level's starting layout. It is not a Godot runtime capture.
- `godot/atelier.tscn`: a separate interactive asset and animation inspector. Open this scene and press F6.

Live rendered Godot captures and an Android APK remain pending. The environment-access step needed for a graphics window and official SDK/template downloads was cancelled before it executed. Headless Godot gameplay validation is complete; this does not establish visual rendering or physical phone performance.

## Editable assets

`blend/bunbreak_master.blend` contains all authoring scenes. Each asset also has an isolated `.blend` under `blend/characters` or `blend/props`. GLB exports are under `exports`; identical copies are included in the Godot project. These are original meshes reconstructed from the supplied screenshots. The AI generated concept turnaround under `references/mochi-concept-v2.png` is a design target, not a rendered model or a supplied production asset.

The 11-bone character skeleton includes Root, Body, Crest, arms, feet, eyes and lids. Editable Breath and Squash shape keys complement bone deformation. Each character includes these eight 60 fps baked clips: `idle`, `blink`, `pull`, `release`, `impact`, `merge`, `hop`, `escape`. Idle loops; event clips play once. Pip's short cap is blended into the Crest bone. Berry and Mango have distinct short petal/crown crests.

Blender uses Z up and faces -Y; GLB/Godot use Y up and face +Z. Model roots sit at ground contact. Materials are untextured PBR colors with explicit UVs and normals. No Draco decoding is required. The sources were built with Blender 4.3.2 and imported into Godot 4.6.3.

## Motion and physics

`godot/scripts/bun_solver.gd` owns fixed 120 Hz planar physics, with four collision substeps. Spring motion never changes bun positions or collision radii. Stable bun IDs and deferred merge removals prevent double consumption in simultaneous contacts. Merging conserves momentum; equal Mango tiers bounce instead of creating an undefined fourth tier.

`bun_motion_driver.gd` owns held pull, release/impact impulses and spring parameters. `bun_modifier.gd` runs after AnimationMixer and owns Body/Crest deformation. An exact damped spring avoids frame-dependent wobble. Height is clamped to 0.72–1.20; both lateral scales use `1/sqrt(height)`, preserving bulk volume. Face and body share the Body transform. A held aim stays squashed; shot physics starts on release.

The original HTML/JavaScript source was unavailable. These are newly implemented physics defaults, not claims of preserving undocumented values: launch cap 12 units/s; drag 1.45/s; circle radii 0.55 / 0.65 / 0.77; masses 1 / 2 / 4; wall restitution 0.82; bun restitution 0.7. Only the specified Big Escape slice is implemented. Other levels and real-device tuning remain future work.

## Validation

`reports/game-validation.json`: 48 passing checks, including real GLB instantiation, clip playback, touch hold/cancel, immediate mouse release, aim simulation, Undo, Retry, pause, mute, high speed jelly collision, simultaneous contacts, tier gates, momentum, volume, portrait/desktop bounds and a complete four-shot solution. Fixed tick replays produce identical final states at 30, 60 and 120 render FPS. This is not a measured frame-rate claim.

`reports/glb-validation.json`: all eight exports have finite transforms, UVs, normals and materials; character exports contain one 11-bone skin, two morph targets and eight unique clips. `data/solution.json` contains the verified physics shots.

To repeat the tests from this folder:

```sh
. authoring/environment.sh
godot --headless --editor --path godot --import
godot --headless --path godot --script tests/validate_game.gd
python3 authoring/validate_glb.py
```

## Rebuild and export

```sh
. authoring/environment.sh
blender -b --factory-startup -t 3 --python authoring/build_assets.py
blender -b --factory-startup -t 2 --python authoring/finalize_sources.py
blender -b blend/bunbreak_master.blend -t 3 --python authoring/render_assets.py
blender -b blend/bunbreak_master.blend -t 3 --python authoring/render_poses.py
```

Godot export presets are included for Android and Linux. For Android, install the matching Godot 4.6.3 export templates, Java 17 or newer, Android platform-tools, build-tools 35.0.1 and platform 35; configure their paths in Godot Editor Settings → Export → Android. Use Export → Android → Export Project with debug enabled. Package name: `org.bunbreak.sunshinekitchen.prototype`; minimum Android 7; ARM64 and ARMv7; Compatibility renderer. No Gradle custom build is required. The APK has not been produced or signed in this environment.

`authoring/setup_android.py` contains the bounded official-tool download workflow; `finish_build.sh` is specific to this managed workspace and also attempts real Godot screenshots/movie capture. It needs environment network/socket access. Each download and export has a timeout, cached steps resume without repeating completed work, and independent local work is preserved.

## Research and attribution

- Exact damped springs: https://theorangeduck.com/page/spring-roll-call
- Godot animation blending: https://docs.godotengine.org/en/4.6/tutorials/animation/animation_tree.html
- Post-animation skeleton modifiers: https://docs.godotengine.org/en/4.6/classes/class_skeletonmodifier3d.html
- Imported animation interpolation: https://docs.godotengine.org/en/4.6/classes/class_animation.html
- Android export: https://docs.godotengine.org/en/4.6/tutorials/export/exporting_for_android.html

Open Sans fonts are bundled under the Apache 2.0 license; see `godot/fonts/LICENSE.txt`. Character and prop geometry, authoring scripts and game implementation were created for this project from the user's handoff screenshots. No original prototype ZIP was available or used. Earlier v1 files are preserved separately.
